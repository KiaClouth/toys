#### 更换字步骤

将.ttf格式的字体文件放入../../font/文件夹
修改index.js里的config对象
最后修改meshwriter.ES.js

项目根目录下运行指令：npm run initialization
